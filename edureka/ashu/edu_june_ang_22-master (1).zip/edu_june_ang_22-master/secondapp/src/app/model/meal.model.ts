export interface IMeal {
    _id: string,
    mealtype_id: number,
    mealtype: string,
    content: string,
    meal_image: string,
    // cost: number,
}