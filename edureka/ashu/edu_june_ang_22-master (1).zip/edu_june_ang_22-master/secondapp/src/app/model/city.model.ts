export interface ICity {
    id: string,
    location_id: number,
    location_name: string,
    state_id: number,
    state: string,
    country_name: string
}