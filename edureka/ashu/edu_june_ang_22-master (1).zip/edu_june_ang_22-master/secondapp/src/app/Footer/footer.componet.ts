import {Component} from '@angular/core';

@Component({
    selector: 'app-footer',
    templateUrl:'./footer.componet.html',
    styleUrls:['./footer.componet.css']
})

export class FooterComponent {}