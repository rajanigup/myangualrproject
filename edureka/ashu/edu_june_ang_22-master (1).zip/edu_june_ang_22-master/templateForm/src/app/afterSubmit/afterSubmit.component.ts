import { Component} from '@angular/core';

@Component({
    templateUrl: './afterSubmit.component.html'
})

export class AfterSubmitComponent {}